// main.jsx — PandaStudioX Vite entry point
import React from "react";
import ReactDOM from "react-dom/client";
import "./global.css";
import App from "./App.jsx";

ReactDOM.createRoot(document.getElementById("root")).render(
  <React.StrictMode>
    <App />
  </React.StrictMode>
);
